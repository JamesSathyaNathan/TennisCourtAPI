﻿
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections;
using TennisCourtApi.Data;
using TennisCourtApi.Models;


namespace TennisCourtApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly AvailabilityContext _dbContext;
        private readonly BookingContext _dbBookingContext;
        public BookingController(AvailabilityContext dbContext)
        {
            _dbContext = dbContext;
        }

        [Authorize]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CourtAvailability>>> GetCourtsAvailability()
        {
            if (_dbContext.Availability == null)
            {
                return NotFound();
            }


            return await _dbContext.Availability.ToListAsync();
        }

        [Authorize]
        [HttpGet("{CourtNumber}")]
        public async Task<ActionResult<CourtAvailability>> GetCourtAvailability(int CourtNumber)
        {
            try
            {
                if (_dbContext.Availability == null)
                {
                    return NotFound();
                }
                var Availability = await _dbContext.Availability.FindAsync(CourtNumber);
                if (Availability == null)
                {
                    return NotFound();
                }
                return Availability;
            }
            catch (Exception ex)
            {

            }
            return NotFound();

        }

        [Authorize]
        [HttpGet("{RefferralId}")]
        public async Task<ActionResult<CourtBooking>> GetBookingDetails(string? RefferralId)
        {
            if (_dbBookingContext.Bookings == null)
            {
                return NotFound();
            }
            var BookingDetails = await _dbBookingContext.Bookings.FindAsync(RefferralId);
            if (BookingDetails == null)
            {
                return NotFound();
            }
            return BookingDetails;
        }

        [Authorize]
        [HttpPost]
        public async Task<ActionResult<CourtBooking>> BookCourt(CourtBooking BookingDetails)
        {
            _dbBookingContext.Bookings.Add(BookingDetails);

            await _dbBookingContext.SaveChangesAsync();

            return CreatedAtAction(nameof(GetBookingDetails), new { BookingDetails.RefferralId });
        }
    }
}
