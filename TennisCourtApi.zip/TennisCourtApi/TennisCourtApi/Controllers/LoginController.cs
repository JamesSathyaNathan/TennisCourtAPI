﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using TennisCourtApi.Models;

namespace TennisCourtApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private IConfiguration _config;

        public LoginController(IConfiguration configuration)
        {
            _config = configuration;
        }
        private LoginUsers AuthenticateUsers(LoginUsers User)
        {
            LoginUsers _user = null;
            if (User.LoginUser == "Admin" && User.LoginPassword == "Admin@123")
            {
                _user = new LoginUsers { LoginUser = "SathyaNathan J" };

            }
            return _user;
        }

        private string GenerateToken(LoginUsers User)
        {
            var securitykey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securitykey, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(_config["Jwt:Issuer"], _config["Jwt:Audience"], null, expires: DateTime.Now.AddMinutes(1),
                signingCredentials: credentials);


            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        [AllowAnonymous]
        [HttpPost]
        public IActionResult Login(LoginUsers user)
        {
            IActionResult response = Unauthorized();
            var _user = AuthenticateUsers(user);
            if(_user!=null)
            {
                var token = GenerateToken(_user);
                response = Ok(new { token = token });
            }
            return response;
        }
    }
}
