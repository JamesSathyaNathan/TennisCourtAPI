﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System;
using TennisCourtApi.Models;

namespace TennisCourtApi.Data
{
    public class AvailabilityContext : DbContext
    {
        public DbSet<CourtAvailability> Availability { get; set; }

        public AvailabilityContext(DbContextOptions<AvailabilityContext> options)
        : base(options)
        { }

    }
}
