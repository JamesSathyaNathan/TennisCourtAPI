﻿using System;
using TennisCourtApi.Models;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace TennisCourtApi.Data
{
    public class BookingContext : DbContext
    {
        public DbSet<CourtBooking> Bookings { get; set; }

        public BookingContext(DbContextOptions<BookingContext> options)
        : base(options)
        { }

    }
}

