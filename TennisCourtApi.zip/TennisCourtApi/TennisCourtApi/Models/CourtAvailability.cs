﻿namespace TennisCourtApi.Data
{
    public class CourtAvailability
    {
        public int Id { get; set; }
        public int CourtNumber { get; set; }
        public string? Availability { get; set; }
    }
}
