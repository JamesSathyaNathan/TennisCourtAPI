﻿namespace TennisCourtApi.Models
{
    public class CourtBooking
    {
        public int Id { get; set; }
        public string? RefferralId { get; set; }
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Address { get; set; }
        public int CourtNumber { get; set; }
        public string? BookingType { get; set; }
        public string? FromDate { get; set; }
        public string? ToDate { get; set; }
    }
}