﻿namespace TennisCourtApi.Models
{
    public class LoginUsers
    {
        public string LoginUser { get; set; }
        public string LoginPassword { get; set; }
    }
}
